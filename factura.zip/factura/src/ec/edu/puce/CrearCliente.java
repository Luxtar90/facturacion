package ec.edu.puce;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JList;
import javax.swing.JProgressBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrearCliente extends JInternalFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;

	DefaultTableModel datatitle = new DefaultTableModel();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrearCliente frame = new CrearCliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CrearCliente() {
		setTitle("Clientes");
		setBounds(100, 100, 450, 491);
		getContentPane().setLayout(null);
		
		JLabel lblCdula = new JLabel("Cédula");
		lblCdula.setBounds(41, 28, 70, 15);
		getContentPane().add(lblCdula);
		
		JLabel lblNombres = new JLabel("Nombres");
		lblNombres.setBounds(41, 68, 70, 15);
		getContentPane().add(lblNombres);
		
		textField = new JTextField();
		textField.setBounds(108, 26, 114, 19);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(108, 66, 231, 19);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblDireccin = new JLabel("Dirección");
		lblDireccin.setBounds(41, 108, 70, 15);
		getContentPane().add(lblDireccin);
		
		textField_2 = new JTextField();
		textField_2.setBounds(108, 106, 231, 19);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblTelfono = new JLabel("Teléfono");
		lblTelfono.setBounds(41, 153, 70, 15);
		getContentPane().add(lblTelfono);
		
		textField_3 = new JTextField();
		textField_3.setBounds(108, 151, 231, 19);
		getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(41, 188, 70, 15);
		getContentPane().add(lblEmail);
		
		textField_4 = new JTextField();
		textField_4.setBounds(108, 186, 231, 19);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNuevo = new JButton("Nuevo");
		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(" ");
                textField_1.setText(" ");
                textField_2.setText(" ");
                textField_3.setText(" ");
                textField_4.setText(" ");
            }
			
		});
		btnNuevo.setBounds(30, 231, 117, 25);
		getContentPane().add(btnNuevo);
		
		JButton btnGuardar = new JButton("Agregar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cabecera [] = {"Cedula", "Nombres", "Direccion", "Telefono", "Email"};
                String datos [][] = new String [5][5];
                datos[0][0] = textField.getText();
                datos[0][1] = textField_1.getText();
                datos[0][2] = textField_2.getText();
                datos[0][3] = textField_3.getText();
                datos[0][4] = textField_4.getText();
                datatitle = new DefaultTableModel(datos, cabecera);
                table.setModel(new DefaultTableModel(datos, cabecera));
            }
			
		});
		btnGuardar.setBounds(157, 231, 117, 25);
		getContentPane().add(btnGuardar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setBounds(286, 231, 117, 25);
		getContentPane().add(btnCancelar);
		
		table = new JTable();
		table.setBounds(30, 274, 373, 156);
		getContentPane().add(table);
		
		

	}
}